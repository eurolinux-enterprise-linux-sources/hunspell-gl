Dicionario galego para o corrector ortogr�fico Hunspell do OpenOffice, compilado e distribu�do en www.mancomun.org
VERSION 2.2

1. Copyright
2. Contido
3. Instalaci�n
4. Normas

1. Sobre os dereitos

Este � un dicionario para OpenOffice baseado no motor Hunspell creado dentro da iniciativa "Mancom�n, Iniciativa Galega polo Software Libre" e desenvolvido usando a normativa vixente en Setembro de 2006.

O dicionario est� liberado baixo os termos da GNU GPL versi�n 2.

Unha copia desta licenza pode atoparse na seguinte p�xina web:

http://www.gnu.org/copyleft/gpl.html


2. Contido

Este corrector componse de:

        gl_ES.dic,  lista de lemas en galego.
        gl_ES.aff,  ten as regras para derivar todas as palabras usando os lemas (estos dous ficheiros van comprimidos no ficheiro gl_ES.zip e son os que conformas o corrector propiamente dito)
        README_gl_ES.txt  este ficheiro


3. Instalaci�n en OpenOffice.org

	a.- Pechar todas as vent�s abertas do OpenOffice e tam�n o "Arranque r�pido", antes de instalar o dicionario.
	b.- Descargar o ficheiro gl_ES-pack.zip.
	c.- Abrir o asistente de instalaci�n de dicionarios do OpenOffice.org e usar o ficheiro anteriormente descargado con este asistente.
	d.- Seguir os pasos do asistente para conclu�r a instalaci�n do dicionario.


4. Normas

Este dicionario segue a normativa ortogr�fica do 12 de Xullo de 2003 Da Real Academia Galega.


